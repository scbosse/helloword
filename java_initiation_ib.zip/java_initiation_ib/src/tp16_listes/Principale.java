package tp16_listes;




public class Principale {
	public static void main(String args[]){
		
	Flux f = new Flux();
	f.create();
	f.correct();
	f.read();
	
	}
}
