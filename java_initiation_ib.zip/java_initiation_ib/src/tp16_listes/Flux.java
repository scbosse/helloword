package tp16_listes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.util.Scanner;

public class Flux {

	public void create() {
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter("input.txt", true));

			bw.write("Bonjour");

			bw.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void correct() {
		BufferedReader br = null;
		String ligne = null;
		try {
			// Instanciation du BufferedReader
			br = new BufferedReader(new FileReader("input.txt"));

			// Affectation de la lecture de la ligne suivante dans ligne
			BufferedWriter bw = null;

			bw = new BufferedWriter(new FileWriter("output.txt", true));

			ligne = br.readLine();
			if (ligne !=null){
				bw.write(ligne);
				bw.close();
				//System.out.println(ligne);

				br.close();
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void read() {
		Scanner sc=new Scanner(System.in);
		System.out.println("entrez un texte a ecrire: ");
		try {
		BufferedWriter bw = new BufferedWriter(new FileWriter("output2.txt", true));
		
			bw.write(sc.nextLine());
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
