package tp10_societe_constructeur;

public class Societe{
	// nom et localite : variables d'instance g�n�r�es
	// pour chaque objet de la classe
	 private String nom;
	 private String loc;
	 
	 
	public Societe() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Societe(String nom, String loc) {
		super();
		this.nom = nom;
		this.loc = loc;
	}



	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getLoc() {
		return loc;
	}


	public void setLoc(String loc) {
		this.loc = loc;
	}


	// methode qui affiche les caract�ristiques
	// de l'objet
	 public void decrisToi(){
		System.out.println("La societe s'appelle " + nom);
		System.out.println("Elle est localisee a " + loc);
	  }
	}

