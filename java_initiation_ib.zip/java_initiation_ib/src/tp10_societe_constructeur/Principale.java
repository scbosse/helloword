package tp10_societe_constructeur;



public class Principale {
	public static void main(String args[]){
		
		Societe java;
		Societe gd ;
		Societe cpp;
		java=new Societe("java","paris");
		cpp=new Societe("cpp","lyon");

		java.decrisToi();
		cpp.decrisToi();
	}
}
