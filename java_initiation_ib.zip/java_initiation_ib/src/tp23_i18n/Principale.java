package tp23_i18n;

import java.util.Locale;
import java.util.ResourceBundle;

public class Principale {

	public static void main(String[] args) {
		 Locale locale = new Locale("fr","");
		 Locale locale_en = new Locale("en","GB");
		 ResourceBundle messages = ResourceBundle.getBundle("tp23_i18n.trad", locale);
		 System.out.println(messages.getString("key.hello")); 
		 ResourceBundle messages_en = ResourceBundle.getBundle("tp23_i18n.trad", locale_en);
		 System.out.println(messages_en.getString("key.hello"));
		 
		}

}
