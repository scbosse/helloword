package tp3_operateurs;

import java.util.Scanner;



public class Operateur {
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		int x;
		System.out.println("Rentrez X maintenant (validez avec entree):");
		x= sc.nextInt();
		int y;
		System.out.println("Rentrez Y maintenant (validez avec entree):");
		y= sc.nextInt();
		System.out.println("addition de X et Y: "+(x+y));
		System.out.println("difference de X et Y: "+(x-y));
		System.out.println("produit de X et Y: "+(x*y));
		System.out.println("quotient de X et Y: "+(x/y));
		sc.close();
	}
}
