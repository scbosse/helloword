package tp14_exceptions;


public class Principale {
	public static void main(String args[]){
		
FeuxSignalisation f= new FeuxSignalisation();
		
		
		try {
			f.changeFeux("rouge");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			System.out.println(e1.getMessage());
		}
		
	
	}
}
