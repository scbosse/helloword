package tp14_exceptions;

public class FeuxSignalisation {
void changeFeux(String feu) throws Exception{
	if(!feu.equals("rouge")&&!feu.equals("vert")&&!feu.equals("orange"))
		throw new Exception("erreur feux");
	
	System.out.println("declenchement normal du feu "+feu);
}
	
}
