package tp11_societe_reference;

public class Societe {
	// nom et localite : variables d'instance g�n�r�es
	// pour chaque objet de la classe
	private String nom;
	private Adresse loc;

	public Societe() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Societe(String nom, Adresse loc) {
		super();
		this.nom = nom;
		this.loc = loc;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Adresse getLoc() {
		return loc;
	}

	public void setLoc(Adresse loc) {
		this.loc = loc;
	}

	// methode qui affiche les caract�ristiques
	// de l'objet
	public void decrisToi() {
		// nom est de type String : non mutable-->passage par recopie
		System.out.println("La societe s'appelle " + nom);
		// System.out.println("Elle est localisee a " + loc); affiche l adresse
		// memoire-->passage par r�f�rence avec les types mutables
		loc.getInfos();
	}
}
