package tp11_societe_reference;



public class Principale {
	public static void main(String args[]){
		
		Adresse a = new Adresse("notre dame", "Paris", 12);
		Societe java;
		Societe cpp;
		//instanciation
		java=new Societe("java",a);
		cpp=new Societe("cpp",a);
		
		//appel de la m�thode decrisToi()
		java.decrisToi();
		cpp.decrisToi();
		//modification du num�ro de l'adresse
		a.setNo(20);
		

		java.decrisToi();
		cpp.decrisToi();
	}
}
