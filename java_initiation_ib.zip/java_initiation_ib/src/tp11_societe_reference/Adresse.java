package tp11_societe_reference;

public class Adresse {

	String nom;
	String ville;
	int no;

	public Adresse() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Adresse(String nom, String ville, int no) {
		super();
		this.nom = nom;
		this.ville = ville;
		this.no = no;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public void getInfos() {
		System.out.println("L'adresse:  " + no + " rue " + nom + " a " + ville);

	}

}
