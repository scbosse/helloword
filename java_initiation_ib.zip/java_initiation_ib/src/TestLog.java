import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.SimpleLayout;

public class TestLog {
	public static void main(String[] args) {
	
 Logger logger = Logger.getLogger("aa");
 logger.setLevel(Level.WARN);
 logger.addAppender(new ConsoleAppender(new SimpleLayout()));
 Logger logger2 = Logger.getLogger("aa.bb");
 Logger logger3 = Logger.getLogger("aa.bb.cc");
 logger3.setLevel(Level.INFO);
 logger.warn("logger warn");
 logger2.debug("logger2 debug");
 logger2.error("logger2 error");
 logger3.info("logger3 info");
}


}
