
import java.*;
public class Personne {
	String nom;
	String prenom;
	

	Personne ()
	{	super();}
	
	Personne(String nom,String prenom)
	{
		this.nom=nom;
		this.prenom=prenom;
	}

	public void setNom(String nom){
		this.nom=nom;
	}
	public String getNom(){
		return this.nom;
	}
	public void setPrenom(String prenom){
		this.prenom=prenom;
	}
	public String getPrenom(){
		return this.prenom;
	}
	
}
