package tp9_societe_get_set;



public class Principale {
	public static void main(String args[]){
		
		Societe java;
		Societe cpp;
		java=new Societe();
		java.setNom("java");
		java.setLoc("paris");
		cpp=new Societe();
		cpp.setNom("cpp");
		cpp.setLoc("lyon");
		java.decrisToi();
		cpp.decrisToi();
	}
}
