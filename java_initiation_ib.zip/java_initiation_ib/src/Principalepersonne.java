
import java.util.Scanner;

public class Principalepersonne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nom,prenom;
		Scanner sc=new Scanner(System.in);
		System.out.println("donner le nom");
		nom=sc.nextLine();
		System.out.println("donner le prenom");
		prenom=sc.nextLine();
Personne p= new Personne (nom,prenom);


System.out.println(p.getNom()+"  "+p.getPrenom());


	}

}
