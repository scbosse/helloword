/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tp19_20_ecole_bd_ihm.ecole;

import java.util.ArrayList;

/**
 *
 * @author beng
 */
public class Cours {

    private String nom;
    private int nbHeure;
    private int annee;
    //je met les eleves à inscrire dans le cours
    private ArrayList<Eleve> listeEleves;

    public Cours() {
        listeEleves = new ArrayList<Eleve>();
    }

    public Cours(String nom, int nbHeure, int annee) {
        this.nom = nom;
        this.nbHeure = nbHeure;
        this.annee = annee;
        this.listeEleves = new ArrayList<Eleve>();
    }

    public int getAnnee() {
        return annee;
    }

    public void setAnnee(int annee) {
        this.annee = annee;
    }

    public int getNbHeure() {
        return nbHeure;
    }

    public void setNbHeure(int nbHeure) {
        this.nbHeure = nbHeure;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void inscritElevesDansCeCours(Eleve e) {
        listeEleves.add(e);
    }

    void afficheInfos() {
        System.out.println(" le cours " + nom + " a " + nbHeure + " heures pour l'annee " + annee);
        System.out.println(" voici les eleves inscrits");
        if (listeEleves.isEmpty()) {
            System.out.println("pas d'eleves dans ce cours");
        } else {
            for (int i = 0; i < listeEleves.size(); i++) {
                Eleve e = listeEleves.get(i);
//            System.out.println("eleve: "+e.getNom() +" "+e.getPrenom()+
//                    " qui a "+e.getAge()+ " a inscrire en "+e.getAnnee());
                e.afficheInfos();
            }
        }


    }
}
