/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tp19_20_ecole_bd_ihm.ecole;

import javax.swing.JFrame;

import tp19_20_ecole_bd_ihm.vue.PanelEleve;

/**
 *
 * @author beng
 */
public class Principale {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Ecole monEcole = new Ecole();

        //Eleve e1 = new Eleve("dupond", "Pierre", 8, 3);
        Eleve e2 = new Eleve("durand", "Paul", 7, 2);

        Cours math = new Cours("Math", 200, 2);
        Cours sport = new Cours("Sport", 70, 3);
        //e1.afficheInfos();
        monEcole.insererCours(math);
        monEcole.insererCours(sport);

        //monEcole.insererEleves(e1);
        monEcole.insererEleves(e2);
        //monEcole.sauverEleves(e1);

        math.inscritElevesDansCeCours(e2);


        JFrame frame = new JFrame();
        //cree le panel
        
        PanelEleve panel = new PanelEleve(monEcole);
        
        frame.getContentPane().add(panel);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
       

/*
        // creer un menu ou je vais choisir les actions
        Scanner sc = new Scanner(System.in);
        Scanner scString = new Scanner(System.in);

        while (1 == 1) {

            System.out.println("menu Principal:");
            System.out.println("1) inscrire Eleve");
            System.out.println("2) inscrire Cours");
            System.out.println("3) affecter eleve dans cours");
            System.out.println("4) afficher les cours");
            System.out.println("5) afficher les eleves");
            System.out.println("6) quitter");

            switch (sc.nextInt()) {
                case 1:
                    //on inscrit d'abord un nouvel eleve
                    System.out.println("le nom?");
                    String e_nom= scString.nextLine();
                    System.out.println("le prenom?");
                    String e_prenom= scString.nextLine();
                    System.out.println("l'age?");
                    int e_age= sc.nextInt();
                    System.out.println("l'annee?");
                    int e_annee= sc.nextInt();
                    Eleve einsert = new Eleve(e_nom, e_prenom, e_age, e_annee);
                    //insert dans liste
                    monEcole.insererEleves(einsert);
                    //insert dans base
                    monEcole.sauverEleves(einsert);
                    break;

                case 2:
                    break;

                case 3:
                    // pour inscrire un eleve dans le cours il faut
                    // que l'eleve soit inscrit à l'ecole
                    // que le cours soit présent dans l'ecole

                    //1) rechercher l'eleve dans l'ecole => en donnant un nom
                    //2) j'affiche les cours disponible
                    //3) j'affecte l'eleve dans le cours
                    System.out.println("donnez le nom d'un eleve");
                    String nom = scString.nextLine();
                    Eleve eleveInscrit = monEcole.rechercherEleveParSonNom(nom);
                    if (eleveInscrit != null) {
                        // suite du traitement
                        System.out.println("eleve trouve:");
                        eleveInscrit.afficheInfos();
                        // on recupere uniquement les cours associé a l'annee de 
                        //l'eleve
                        ArrayList<Cours> mesCoursCompatible =
                                monEcole.rechercherCoursParAnneeDeEleve(eleveInscrit);
                        if(!mesCoursCompatible.isEmpty()){
                            for (int i = 0; i < mesCoursCompatible.size(); i++) {
                                Cours c = mesCoursCompatible.get(i);
                                //affichage pour selection
                                System.out.println(i+") "+c.getNom());

                            }
                            System.out.println("choisir");
                            int choixIndex= sc.nextInt();
                            //on recupere le cours ici
                            //Cours coursChoisi= monEcole.rechercherCoursParIndex(choixIndex);
                            Cours coursChoisi=mesCoursCompatible.get(choixIndex);
                            // incription
                            coursChoisi.inscritElevesDansCeCours(eleveInscrit);
                            System.out.println(eleveInscrit.getNom()+" est inscrit en " +
                                  coursChoisi.getNom()  );
                        }
                        else{
                            System.out.println("pas de cours dispo pour cet eleve");
                        }

                    } else {
                        System.out.println("pas d'eleve trouve");
                    }

                    break;

                case 4:
                    monEcole.afficherListeCours();
                    break;

                case 5:
                    monEcole.afficherListeEleves();
                    break;

                case 6:
                    return;

                default:
                    System.out.println("choix incorrect");
            }
        }
        
        
         */
    }
}
