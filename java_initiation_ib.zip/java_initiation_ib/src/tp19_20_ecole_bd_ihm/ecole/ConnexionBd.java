/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tp19_20_ecole_bd_ihm.ecole;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * pour se connecter à la base, renvoi un objet Connection
 *
 * @author beng
 */
public class ConnexionBd {


        private String login = "root";
        /**
         * < L'utilisateur MySQL
         */
        private String password = "";
        /**
         * < Son mot de passe
         */
        private String host = "localhost";
        /**
         * < L'host de la base
         */
        private String dbName = "next_eleve";
        /**
         * < Le nom de la base
         */
        private int port = 3306;

        /**
         * < Le port de MySQL
         */
        // Cette méthode lève une exception si le connecteur n'est pas installé
        //fonction qui se connecte
        public Connection getConnection() throws ClassNotFoundException, SQLException {
            Class.forName("com.mysql.jdbc.Driver");
            String URL = "jdbc:mysql://" + host + ":" + port + "/" + dbName;
            return DriverManager.getConnection(URL, login, password);

        }
 }
