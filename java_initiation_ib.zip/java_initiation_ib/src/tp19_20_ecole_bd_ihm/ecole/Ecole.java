/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tp19_20_ecole_bd_ihm.ecole;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author beng
 */
public class Ecole {
    ArrayList<Eleve> mesEleves;
    ArrayList<Cours> mesCours;
    

    public Ecole() {
        mesEleves=new ArrayList<Eleve>();
        mesCours = new ArrayList<Cours>();
        //charger lors de la creation de l'ecole
        chargerElevesDepuisBD();
    }
    
    

    public ArrayList<Eleve> getMesEleves() {
        return mesEleves;
    }

    public void setMesEleves(ArrayList<Eleve> mesEleves) {
        this.mesEleves = mesEleves;
    }
    
    public void insererEleves(Eleve e){
        mesEleves.add(e);
    }
    
    public void afficherListeEleves(){
        System.out.println("voici les eleves inscris");
        for(int i=0;i<mesEleves.size();i++){
            Eleve e = mesEleves.get(i);
//            System.out.println("eleve: "+e.getNom() +" "+e.getPrenom()+
//                    " qui a "+e.getAge()+ " a inscrire en "+e.getAnnee());
            e.afficheInfos();
        }
    }
    
    public void afficherListeCours(){
        for(int i=0;i<mesCours.size();i++){
            Cours c = mesCours.get(i);
           
            c.afficheInfos();   
                
         }
    }
    
    public void insererCours(Cours c){
        mesCours.add(c);
    }
    
    public Eleve rechercherEleveParSonNom(String nom){
         for(int i=0;i<mesEleves.size();i++){
            Eleve e = mesEleves.get(i);
            if(e.getNom().equals(nom))
                return e;
         }
        return null; 
        
    }
    
    public ArrayList<Cours> rechercherCoursParAnneeDeEleve(Eleve eleveAInscrire){
        ArrayList<Cours> lesCoursAutorise = new ArrayList<Cours>();
        for(int i=0;i<mesCours.size();i++){
            Cours c = mesCours.get(i);
            //on met dans la liste tous les cours compatible avec l'annee de l'eleve
            if(c.getAnnee()==eleveAInscrire.getAnnee()){
                lesCoursAutorise.add(c);
                }
                
         }
        
        return lesCoursAutorise;
    }
    
    public Cours rechercherCoursParIndex(int index){
        return mesCours.get(index);
    }
    
    
    
    public void sauverEleves(Eleve e){
        
        ConnexionBd bd= new ConnexionBd();
        Connection conn =null;
        try {
            //etape 1,2,3
            conn = bd.getConnection();
            //etape 4
            Statement stmt = conn.createStatement();
            //etape 5
            stmt.executeUpdate("INSERT INTO eleve ( nom, prenom, age, annee) "
                    + "VALUES ( '"+e.getNom()+"', '"+e.getPrenom()+"', "+e.getAge()+", "+e.getAnnee()+");");
            //pas d'etape 6, pas de parcours
            
            System.out.println("eleve "+e.getNom()+" sauvé en base");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ecole.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ecole.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            try {
                //etape 7
                conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(Ecole.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    
    }
    
    
    public void chargerElevesDepuisBD(){
        mesEleves.clear();
        ConnexionBd bd= new ConnexionBd();
        Connection conn =null;
        try {
            //etape 1,2,3
            conn = bd.getConnection();
            //etape 4
            Statement stmt = conn.createStatement();
            //etape 5
            ResultSet res = stmt.executeQuery("SELECT id_eleve,nom,prenom,age,annee FROM eleve");
            //etape 6,  parcours
            while(res.next()){
                Eleve e = new Eleve();
                e.setNom(res.getString("nom"));
                e.setPrenom(res.getString("prenom"));
                e.setAge(res.getInt("age"));
                e.setAnnee(res.getInt("annee"));
                mesEleves.add(e);
            }
          
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Ecole.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(Ecole.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            try {
                //etape 7
                conn.close();
            } catch (SQLException ex) {
                Logger.getLogger(Ecole.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
