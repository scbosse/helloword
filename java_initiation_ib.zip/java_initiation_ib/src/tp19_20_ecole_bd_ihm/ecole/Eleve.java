/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package tp19_20_ecole_bd_ihm.ecole;

/**
 *
 * @author beng
 */
public class Eleve {

    String nom;
    String prenom;
    int age;
    int annee;

    public Eleve() {
    }

    public Eleve(String nom, String prenom, int age, int annee) {
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.annee = annee;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getAnnee() {
        return annee;
    }

    public void setAnnee(int annee) {
        this.annee = annee;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void afficheInfos() {
        System.out.println("eleve: " + getNom() + " " + getPrenom()
                + " qui a " + getAge() + " ans a inscrire en " + getAnnee() + " annee");
    }

    @Override
    public String toString() {
        return getNom() + " " + getPrenom();
    }
    
    
}
