package tp4_conditions;

import java.util.Scanner;



public class Condition {
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		int x;
		System.out.println("Rentrez X maintenant (validez avec entree):");
		x= sc.nextInt();
		int y;
		System.out.println("Rentrez Y maintenant (validez avec entree):");
		y= sc.nextInt();
		if((x >0 && y < 0) || (x< 0 && y > 0)){
			System.out.println("le produit est negatif");
		}
		else{
			System.out.println("le produit est positif");
		}
		
		sc.close();
	}
}
