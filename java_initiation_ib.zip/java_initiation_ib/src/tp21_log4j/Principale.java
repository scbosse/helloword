package tp21_log4j;



import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.SimpleLayout;

public class Principale {

	public static void main(String[] args) {
		
		 Logger logger = Logger.getLogger("package");
		 //logger.setLevel(Level.WARN);
		 //logger.addAppender(new ConsoleAppender(new SimpleLayout()));
		 PropertyConfigurator.configure("src/tp21_log4j/mylogging.properties");
		 logger.warn("logger warn");
		
		}

}
