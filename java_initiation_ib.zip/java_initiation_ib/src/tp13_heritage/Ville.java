package tp13_heritage;

public class Ville {
 protected String nom;
 protected int nbH;
 
 public Ville(String nom, int nbH) {
	super();
	this.nom = nom;
	this.nbH = nbH;
}

public Ville() {
		super();
		// TODO Auto-generated constructor stub
	}

public String getNom() {
	return nom;
}

public void setNom(String nom) {
	this.nom = nom;
}

public int getNbH() {
	return nbH;
}

public void setNbH(int nbH) {
	this.nbH = nbH;
}
 
void affiche(){
	System.out.println("ville "+nom.toUpperCase()+" qui a "+nbH+" habitants ");
}
 
}
