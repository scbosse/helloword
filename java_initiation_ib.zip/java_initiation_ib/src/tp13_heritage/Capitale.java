package tp13_heritage;

public class Capitale extends Ville{
	String pays;
	public Capitale() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Capitale(String nom, int nbH) {
		super(nom, nbH);
		// TODO Auto-generated constructor stub
	}

	public Capitale(String nom, int nbH, String pays) {
		super(nom, nbH);
		this.pays = pays;
	}
	
	@Override
	void affiche() {
		// TODO Auto-generated method stub
		super.affiche();
		System.out.println("je suis la capitale de "+pays);
	}
	

}
