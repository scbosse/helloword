package tp13_heritage;


import java.util.ArrayList;
import java.util.List;



public class MainHeritage {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Ville> mesVilles = new ArrayList<Ville>();
		mesVilles.add(new Ville("bordeau",5000000));
		mesVilles.add(new Ville("toulouse",6000000));
		mesVilles.add(new Capitale("Paris",10000000,"France"));
		
		for(Ville v:mesVilles)
			v.affiche();
	
	}

}
