package tp22_junit;

public class MoneyImp implements Money {
	
	int amount;
	String currency;

	public MoneyImp(int montant,String currency) {
		super();
		amount=montant;
		this.currency=currency;
		
		// TODO Auto-generated constructor stub
	}
	
	
	public MoneyImp() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getAmount() {
		// TODO Auto-generated method stub
		return amount;
	}


	public String getCurrency() {
		// TODO Auto-generated method stub
		return currency;
	}

	
	public Money add(Money m) {
		// TODO Auto-generated method stub
		return null;
	}

	
	public Money add(int amount, String curency) {
		// TODO Auto-generated method stub
		
		if(this.currency.equals(curency))
			return new MoneyImp(amount+this.amount, curency);
		
		
			return null;
	}

}
