package tp22_junit;

//importez junit dans eclipse pour compiler cette correction
//click droit sur projet -> property -> java buildpath
// onglet libraries -> bouton add library -> junit -> v4

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;




public class TestMoney {
    Money m;
	
	@Before
	public void init(){
	m=new MoneyImp(10,"JPY");
	}
	
	
	@After
	public void destroy(){
		
	}
	
	@Test
	public void testGetter(){
	//scenario est l'utilisation du getter
		assertEquals(m.getAmount(),10);
		assertEquals(m.getCurrency(),"JPY");

	}
	
	
	@Test
	public void testAjout2arguments(){
	//scenario est l'utilisation de add(montant,currency)
		
		Money res = m.add(20, "JPY");
		assertEquals(res.getAmount(),30);
		assertEquals(res.getCurrency(),"JPY");
		
		res = m.add(-50,"JPY");
		assertEquals(res.getAmount(),-40);
		assertEquals(res.getCurrency(),"JPY");
		
		res = m.add(10, "CNY");
		assertNull(res);


	}
	
	
	
}
