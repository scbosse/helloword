package tp22_junit;


	public interface Money {
		//pour implementation rajouter des constructeurs
		
		 public int getAmount();
		 public String getCurrency();
		 public Money add(Money m);
		 public Money add(int amount,String curency);
	}


