package tp18_flux;

import java.util.List;

public class Recherche {

	public int getMax(List<Integer> liste) {
		int max=-1;
		for (int i = 0; i < liste.size(); i++) {
			if(max<liste.get(i))
				max=liste.get(i);
			
		}
		
		return max;


	}
	
	
	public void permute(int a,int b,List<Integer> liste) {
		int tmp=liste.get(b);
		liste.set(b, liste.get(a));
		liste.set(a, tmp);
		
	}
	
}
