package tp18_flux;

import java.util.ArrayList;
import java.util.List;



public class Principale {
	public static void main(String args[]){
		
		List<Integer> liste = new ArrayList<Integer>();
		liste.add(10);
		liste.add(20);
		liste.add(0);
		
		Recherche cal = new Recherche();

		//Scanner sc=new Scanner(System.in);
		
		System.out.println("Max: "+cal.getMax(liste) );
		System.out.println("avant: "+liste.get(0)+" et "+liste.get(2) );
		cal.permute(0, 2, liste);
		System.out.println("apres: "+liste.get(0)+" et "+liste.get(2) );
	
	}
}
