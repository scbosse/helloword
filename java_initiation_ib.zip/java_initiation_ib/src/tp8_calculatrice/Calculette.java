package tp8_calculatrice;

public class Calculette {
	int addition(int a, int b) {
		return a + b;
	}

	int soustration(int a, int b) {
		return a - b;
	}

	int multiplication(int a, int b) {
		return a * b;
	}

	int division(int a, int b) {
		return a / b;
	}
}
