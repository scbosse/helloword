package tp8_calculatrice;

import java.util.Scanner;

public class Principale {
	public static void main(String args[]){
		int a,b;
		Scanner sc=new Scanner(System.in);
		Calculette cal;
	
		cal=new Calculette();
		System.out.println("donner a");
		a=sc.nextInt();
		System.out.println("donner b");
		b=sc.nextInt();
		System.out.println(cal.addition(a, b));
		System.out.println(cal.soustration(a, b));
		System.out.println(cal.multiplication(a, b));
		System.out.println(cal.division(a, b));
	}
}
