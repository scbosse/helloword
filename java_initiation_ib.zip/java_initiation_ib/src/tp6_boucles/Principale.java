package tp6_boucles;

import java.util.Scanner;

public class Principale {
	public static void main(String args[]) {

		Dessin cal;

		cal = new Dessin();

		Scanner sc = new Scanner(System.in);
		System.out.println("choix");
		cal.dessine(sc.nextInt());

	}

}
