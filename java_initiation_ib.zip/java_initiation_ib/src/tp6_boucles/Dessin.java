package tp6_boucles;

public class Dessin {

	public void dessine(int a) {

		for (int i = 0; i < a; i++) {
			System.out.print("*");
			
		}
		System.out.println();
		System.out.println();
		for (int i = 0; i < a; i++) {
			for (int j = 0; j < a; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		System.out.println();
		for (int i = 0; i < a; i++) {
			for (int j = 0; j < a; j++) {
				System.out.print("*");
				if(i==j){
					System.out.println();
					break;
				}
			}
			
		}


	}
}
