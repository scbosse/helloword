package tp12_ecole;

import java.util.ArrayList;

public class Cours {
	private Long id;
	private String nom;
	private int nb_heures;
	private int annee;
	ArrayList<Eleve> mesElevesInscrit;

	// getter/setter
	public void setMesElevesInscrit(ArrayList<Eleve> mesElevesInscrit) {
		this.mesElevesInscrit = mesElevesInscrit;
	}

	public ArrayList<Eleve> getMesElevesInscrit() {
		return mesElevesInscrit;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the nom
	 */
	public String getNom() {
		return nom;
	}

	/**
	 * @param nom
	 *            the nom to set
	 */
	public void setNom(String nom) {
		this.nom = nom;
	}

	/**
	 * @return the nb_heures
	 */
	public int getNb_heures() {
		return nb_heures;
	}

	/**
	 * @param nb_heures
	 *            the nb_heures to set
	 */
	public void setNb_heures(int nb_heures) {
		this.nb_heures = nb_heures;
	}

	/**
	 * @return the annee
	 */
	public int getAnnee() {
		return annee;
	}

	/**
	 * @param annee
	 *            the annee to set
	 */
	public void setAnnee(int annee) {
		this.annee = annee;
	}

	// constructeurs
	public Cours(String nom, int nb_heures, int annee) {
		super();
		this.nom = nom;
		this.nb_heures = nb_heures;
		this.annee = annee;
		mesElevesInscrit = new ArrayList<Eleve>();
	}

	public Cours() {
		mesElevesInscrit = new ArrayList<Eleve>();

	}

	// M�thodes
	public void affiche() {
		System.out.println("nom :" + nom);
		System.out.println("nombre heures :" + nb_heures);
		System.out.println("annee :" + annee);
		if (mesElevesInscrit.size() != 0) {
			for (Eleve e : mesElevesInscrit) {
				e.affiche();
			}
		} else
			System.out.println("aucun eleve inscrit");

	}

	public void inscriptionCours(Eleve e) {
		mesElevesInscrit.add(e);
		
	}

}
