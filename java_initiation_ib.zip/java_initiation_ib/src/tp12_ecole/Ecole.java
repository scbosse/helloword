package tp12_ecole;

import java.util.ArrayList;

public class Ecole {
	
	ArrayList<Eleve> mesEleves ;
	ArrayList<Cours> mesCours;
	public Ecole() {
		super();
		mesEleves = new ArrayList<Eleve>();
		mesCours = new ArrayList<Cours>();
		// TODO Auto-generated constructor stub
	}
	public Ecole(ArrayList<Eleve> mesEleves, ArrayList<Cours> mesCours) {
		super();
		this.mesEleves = mesEleves;
		this.mesCours = mesCours;
	}
	public ArrayList<Eleve> getMesEleves() {
		return mesEleves;
	}
	public void setMesEleves(ArrayList<Eleve> mesEleves) {
		this.mesEleves = mesEleves;
	}
	public ArrayList<Cours> getMesCours() {
		return mesCours;
	}
	public void setMesCours(ArrayList<Cours> mesCours) {
		this.mesCours = mesCours;
	}
//Inscription/ajout d'un �l�ve
	
	public void inscription(Eleve e){
		mesEleves.add(e);
		
		
	}
	//ajout d'un cours � la liste des cours
	
	public void ajouteCours(Cours c ){
		mesCours.add(c);
		
	}
	//rechercher un �l�ve dans la liste des �l�ves par son nom ou son prenom
	public Eleve rechercherEleves(String chaine){
		for(Eleve e: mesEleves){
			
			if(e.getNom().contains(chaine) || e.getPrenom().contains(chaine))
			 return e;
		}
		
		return null;
		
	}
//rechercher les cours correspondants � un choix de l'annee 
	public ArrayList<Cours> recherchercCours(int annee){
		ArrayList<Cours> coursChoisi=new ArrayList<Cours>();
		for(Cours c:mesCours){
			if(c.getAnnee()==annee)
			 coursChoisi.add(c);
		}
		return coursChoisi;
	}
	//lister les cours dispo
	public void listerCours(){
		for(int i=0;i<mesCours.size();i++){
			mesCours.get(i).affiche();
		}
	}




}
