package tp12_ecole;

import java.util.ArrayList;
import java.util.Scanner;

public class Principale {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Eleve e = new Eleve("toto", "titi", 7, 2);
		Cours c= new Cours("sport", 250, 2);
		Cours c2= new Cours("Math", 250, 2);
		Cours c3= new Cours("Math", 250, 3);
		Ecole ecole = new Ecole();
		ecole.ajouteCours(c3);
		ecole.ajouteCours(c2);
		ecole.ajouteCours(c);
		e.affiche();
		c.affiche();
		c =null;
		c2.affiche();
		
		
		Scanner scInt= new Scanner(System.in);
		Scanner scLine= new Scanner(System.in);
		int choix = 0;
		while(choix !=2){
			
		System.out.println("choisissez" );	
		System.out.println("1- creer eleve" );
		System.out.println("2- quitter" );
		System.out.println("3- affecter eleve/cours" );
		System.out.println("4- description des cours" );
		choix= scInt.nextInt(); 
		
		switch (choix) {
		case 1:
			//insertion
			System.out.println("nom" );
			String nom=scLine.nextLine();
			System.out.println("prenom" );
			String prenom=scLine.nextLine();
			System.out.println("age" );
			int age=scInt.nextInt();
			System.out.println("annee" );
			int annee=scInt.nextInt();
			Eleve e2 = new Eleve(nom, prenom, age, annee);
			//inscription m�thode de la classe Ecole
			ecole.inscription(e2);
			System.out.println("eleve inscrit" );
			break;
		case 3:
			//rechercher un eleve 
			System.out.println("Vous cherchez quel eleve?" );
			String chaine=scLine.nextLine();
			Eleve eleveChoisi = ecole.rechercherEleves(chaine);
			
			//cours � proposer � cet �l�ve
			ArrayList<Cours> listCoursDispo = ecole.recherchercCours(eleveChoisi.getAnnee());
			System.out.println("voici les cours dispo.Faites votre choix" );
			for(int i=0;i<listCoursDispo.size();i++){
				System.out.println(i+"- "+listCoursDispo.get(i).getNom());
			}
			//choisir le cours � affecter
			System.out.println("saisissez un no de cours" );
			int no=scInt.nextInt();
			Cours coursChoisi = listCoursDispo.get(no);
			coursChoisi.inscriptionCours(eleveChoisi);
			
			break;
			
			case 4:
				ecole.listerCours();
				break;
		default:
			break;
		}
		
		}
	}

}
