package tp12_ecole;

public class Eleve {
	private long id;
	private String nom;
	private String prenom;
	private int age;
	private int annee;

	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAnnee() {
		return annee;
	}

	public void setAnnee(int annee) {
		this.annee = annee;
	}

	public Eleve() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Eleve(String nom, String prenom, int age, int annee) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.age = age;
		this.annee = annee;
	}
	public void affiche() {
		System.out.println("nom :" + nom);
		System.out.println("prenomm :" + prenom);
		System.out.println("age :" + age);
		System.out.println("annee :" + annee);
	}
}
