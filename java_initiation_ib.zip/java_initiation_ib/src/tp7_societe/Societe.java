package tp7_societe;

public class Societe{
	// nom et localite : variables d'instance generees
	// pour chaque objet de la classe
	  String nom;
	  String loc;
	// methode qui affiche les caracteristiques
	// de l'objet
	  void decrisToi(){
		System.out.println("La societe s'appelle " + nom);
		System.out.println("Elle est localisee a " + loc);
	  }
	}

