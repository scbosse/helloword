package tp7_societe;



public class Principale {
	public static void main(String args[]){
		
		Societe java;
		Societe cpp;
		java=new Societe();
		java.nom="java";
		java.loc="paris";
		cpp=new Societe();
		cpp.nom="cpp";
		cpp.loc="lyon";
		java.decrisToi();
		cpp.decrisToi();
	}
}
