package tp17_calendrier;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class Principale {
	public static void main(String args[]){
		Scanner sc=new Scanner(System.in);
		System.out.println("entrez une date(dd/MM/yyyy): ");
		SimpleDateFormat sf = new SimpleDateFormat("dd/MM/yyyy");
		Date d = null;
		//v�rification de la saisie
		try {
			d = sf.parse(sc.nextLine());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//pour la manipulation de la date saisie, on utilise Calendar 
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		//.add() : permet de modifier un �l�ment de la date en tenant compte des impacts
		//sur les autres �l�ments qui composent la date
		c.add(Calendar.YEAR, 1);
		SimpleDateFormat sf2 = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println(sf2.format(c.getTime()));
		
		
		}
	
	
}
