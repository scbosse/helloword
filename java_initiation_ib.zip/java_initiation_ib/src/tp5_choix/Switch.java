package tp5_choix;

import java.util.Scanner;

public class Switch {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int x;
		System.out.println("Rentrez 1 pour ouvrir, 2 pour quitter ou 3 pour sauver (validez avec entree):");
		x = sc.nextInt();

		switch (x) {
		case 1:
			System.out.println("ouverture");
			break;
		case 2:
			System.out.println("quitter");
			break;
		case 3:
			System.out.println("sauver");
			break;

		default:
			System.out.println("choix inconnu");
			break;
		}

		sc.close();
	}
}
